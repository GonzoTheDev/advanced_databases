# Global Query

The global query aims to return total vote counts for each age group in each county, and is supposed to retrieve the age group description from the age group dimension document along with county and vote counts from the fact documents. I was unable to get this query to function correctly.

# Partition Query

The partition query aims to return all the data for each document within a county partition, the partitions I have set are the counties Kerry and Wicklow.